{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf200
{\fonttbl\f0\froman\fcharset0 Times-Roman;\f1\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\sl280\partightenfactor0

\f0\fs24 \cf2 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 This is a Lab 2 submission for group 6\
Team Members: Joanne Kim (jk3740), Sarina Xie (), Salon Conley ()
\f1 \cf0 \kerning1\expnd0\expndtw0 \outl0\strokewidth0 \
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\pardirnatural\partightenfactor0
\cf0 \
We decided to rely on two packages, shapely and pygame. Shapely would allow us to construct the obstacles and perform calculations checking if the paths or points generated collided with the obstacles. Pygame would allow us to produce a 2-D visual display easily. We could then put shapes, lines, and points on the generated display. \
\
We chose a black background. We set the obstacles to the color yellow; the start and goal to green; lines to white; possible points to red. \
\
First, we would generate the display and begin to add the obstacles and the starting, ending points to the display. We would then also convert the starting and ending points to our data structure, Node.\
\
We create a random node and check if it collides with any other point. If not, we then create another point. We check for collision for the new point. We then also check for possible collision from a line between the two points. If any point fails the conditions, we continue to create new points until we receive a satisfactory point. \
\
We also add each satisfactory node to a list of nodes. \
\
We also continue to check for distance. EPSILON is the smallest radius from the goal point that is acceptable to end the program. If the latest point has a distance of under EPSILON, then the program ends. \
\
We then use Djikstra\'92s algorithm to find the shortest route which we mark with red nodes on the display. \
\
For Part 2, we did the similar thing. We generated two nodes instead and checked them until these two nodes fit our qualifications. If they passed those conditions again, we added them to two separate lists - From_Goal and From_Start. We then checked if all generated, approved points were under EPSILON distance. If they were, we would link the points together. \
\
Then, we would combine the two lists into a overarching list. \
\
Total = From_Goal + From_Start\
\
We would apply Dijkstra\'92s path finding algorithm to the nodes once again and mark the points with the color red. }